<?php
include "../../../koneksi.php";

if(isset($_POST['tombolubah'])){
    $idbuku = $_POST['idbuku'];
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];

    $sql = "UPDATE tbl_buku SET idbuku='$idbuku', judul='$judul', 
        pengarang='$pengarang', penerbit='$penerbit' WHERE 
        idbuku='$idbuku'";

    $query = mysqli_query($conn, $sql);
    
    if ($query) {
        echo "<sript>alert('Data Berhasil di Ubah');</script>";
        header("Location: ../../index.php?page=buku");
    }else{
         echo "<sript>alert('Data Gagal di Ubah');</script>";
        header("Location: ../../index.php?page=bukuubah");
    }
}
?>