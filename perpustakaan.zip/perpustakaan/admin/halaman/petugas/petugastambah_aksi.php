<?php
include "../../../koneksi.php";

if(isset($_POST['tomboltambah'])){
    $namapetugas = $_POST['namapetugas'];
    $username = $_POST['username'];
    $hp = $_POST['hp'];
    $password = $_POST['pass'];
    $cpassword = $_POST['cpass'];

    if($password !=$cpassword) {
        echo "<sript>alert('Password Tidak Sesuai');</script>";
        header("Location: ../../index.php?page=petugastambah");
        exit;
    }

    $sql = "INSERT INTO tbl_petugas (namapetugas, username, hp, password)
            VALUE ('$namapetugas', '$username', '$hp', '$password')";

    $query = mysqli_query($conn, $sql);
    
    if ($query){
        echo "<sript>alert('Data Berhasil di Simpan');</script>";
        header("Location: ../../index.php?page=petugas");
    }else{
         echo "<sript>alert('Data Gagal di Simpan');</script>";
        header("Location: ../../index.php?page=petugastambah");
    }
}
?>