<?php
include "../../../koneksi.php";

if(isset($_POST['tombolubah'])){
    $idpetugas = $_POST['idpetugas'];
    $namapetugas = $_POST['namapetugas'];
    $username= $_POST['username'];
    $hp= $_POST['hp'];
    $password = $_POST['pass'];
    $cpassword = $_POST['cpass'];

    if($password !=$cpassword) {
        echo "<sript>alert('Password Tidak Sesuai');</script>";
        header("Location: ../../index.php?page=petugastambah");
        exit;
}
    
    $sql = "UPDATE  tbl_petugas SET namapetugas='$namapetugas', username='$username',
        hp='$hp', password='$password', hp='$hp' WHERE 
        idpetugas=$idpetugas";

    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('Data Berhasil di Ubah');</script>";
        header("Location: ../../index.php?page=petugas");
    } else {
        echo "<script>alert('Data Gagal di Ubah');</script>";
        header("Location: ../../index.php?page=petugasubah&idpetugas=1");
    }
}
?>