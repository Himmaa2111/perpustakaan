<?php

include "../../../koneksi.php";

$idpetugas = $_GET['idpetugas'];

$sql = "DELETE from tbl_petugas WHERE idpetugas = $idpetugas";
$query = mysqli_query($conn, $sql);
    
    if ($query) {
        echo "<sript>alert('Data Berhasil di Hapus');</script>";
        header("Location: ../../index.php?page=petugas");
    }else{
         echo "<sript>alert('Data Gagal di Hapus');</script>";
        header("Location: ../../index.php?page=petugas");
    }

?>