<?php
include "../../../koneksi.php";

if(isset($_POST['tomboltambah'])){
    $nis = $_POST['nis'];
    $namasiswa = $_POST['namasiswa'];
    $kelas = $_POST['kelas'];
    $alamat = $_POST['alamat'];
    $hp = $_POST['hp'];

    $sql = "INSERT INTO tbl_siswa (nis, namasiswa, kelas, alamat, hp)
            VALUE ('$nis', '$namasiswa', '$kelas', '$alamat', '$hp')";

    $query = mysqli_query($conn, $sql);
    
    if ($query){
        echo "<sript>alert('Data Berhasil di Simpan');</script>";
        header("Location: ../../index.php?page=siswa");
    }else{
         echo "<sript>alert('Data Gagal di Simpan');</script>";
        header("Location: ../../index.php?page=siswatambah");
    }
}
?>