<?php
include "../../../koneksi.php";

if(isset($_POST['tombolubah'])){
    $idsiswa = $_POST['idsiswa'];
    $nis = $_POST['nis'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $alamat = $_POST['alamat'];
    $hp = $_POST['hp'];

    $sql = "UPDATE  tbl_siswa SET nis='$nis', namasiswa='$nama',
        kelas='$kelas', alamat='$alamat', hp='$hp' WHERE 
        idsiswa=$idsiswa";

    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('Data Berhasil di Ubah');</script>";
        header("Location: ../../index.php?page=siswa");
    } else {
        echo "<script>alert('Data Gagal di Ubah');</script>";
        header("Location: ../../index.php?page=siwaubah&idsiswa=1");
    }
}
?>