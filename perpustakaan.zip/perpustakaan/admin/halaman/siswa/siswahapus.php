<?php

include "../../../koneksi.php";

$idsiswa = $_GET['idsiswa'];

$sql = "DELETE from tbl_siswa WHERE idsiswa = $idsiswa";
$query = mysqli_query($conn, $sql);
    
    if ($query) {
        echo "<sript>alert('Data Berhasil di Hapus');</script>";
        header("Location: ../../index.php?page=siswa");
    }else{
         echo "<sript>alert('Data Gagal di Hapus');</script>";
        header("Location: ../../index.php?page=siswa");
    }

?>