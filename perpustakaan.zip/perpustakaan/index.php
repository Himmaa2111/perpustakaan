<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan | SMK Negeri 1 SAYUNG</title>
</head>
<body>
    <h2><center>Aplikasi perpustakaan</center></h2>
    <h2><center>SMK Negeri 1 Sayung</center></h2>

    <?php
    if (isset($_GET['pesan'])) {
        if ($_GET['pesan'] == "gagal") {
            echo "Gagal login! Username atau password salah.";
        } elseif ($_GET['pesan'] == "logout") {
            echo "Anda telah logout";
        } elseif ($_GET['pesan'] == "belum_login") {
            echo "Anda harus login dahulu untuk mengakses halaman admin";
        }
    }
    ?>

    <form action="login_aksi.php" method="post">
        <table align='center'>
            <tr>
                <td>Username</td>
                <td><input type="text" name="username" placeholder="Masukkan Username"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" placeholder="Masukkan Password"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="tombollogin" value="LOGIN"></td>
            </tr>
        </table>
    </form>
</body>
</html>